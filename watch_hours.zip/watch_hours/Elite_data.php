<?php





$useragent = "Mozilla/5.0 (Linux; Android 6.0.1; SM-G532G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Mobile Safari/537.36";

$autologin = "ses_user%3DSyaiful1986%26ses_hash%3D31f1dbf1d8b2e8b83eac59804107880e";

$ssid = "t8vmvgsoffs01u7ddto5l78ir4";



//  DATA LOGIN
$username = "Syaiful1986";
$pass = "akbarganteng";
